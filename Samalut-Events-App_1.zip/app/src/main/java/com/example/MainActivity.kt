package com.example

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ui.navigation.Screen
import com.example.ui.screens.EventFormScreen
import com.example.ui.screens.EventsScreen
import com.example.ui.screens.FirstTimeSetupScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ReportTextScreen
import com.example.ui.screens.SchoolsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.TeachersScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AppDataViewModel
import com.example.ui.viewmodel.AuthViewModel

class MainActivity : FragmentActivity() {

    private val authViewModel: AuthViewModel by viewModels()
    private val dataViewModel: AppDataViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppContent(
                    authViewModel = authViewModel,
                    dataViewModel = dataViewModel
                )
            }
        }
    }
}

@Composable
fun MainAppContent(
    authViewModel: AuthViewModel,
    dataViewModel: AppDataViewModel
) {
    val navController = rememberNavController()
    val authState by authViewModel.authState.collectAsState()
    val adminConfig by dataViewModel.adminConfig.collectAsState()
    val schools by dataViewModel.schools.collectAsState()
    val teachers by dataViewModel.teachers.collectAsState()
    val events by dataViewModel.events.collectAsState()
    val reportDraft by dataViewModel.reportDraft.collectAsState()

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        // Splash (كما هي)
        composable(Screen.Splash.route) {
            SplashScreen(
                isAuthenticated = authState.isAuthenticated,
                onNavigateNext = { isAuth ->
                    val target = when {
                        !adminConfig.isSetupCompleted -> Screen.FirstTimeSetup.route
                        isAuth -> Screen.Home.route
                        else -> Screen.Login.route
                    }
                    navController.navigate(target) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        // الإعداد الأولي لأول مرة (كما هو)
        composable(Screen.FirstTimeSetup.route) {
            FirstTimeSetupScreen(
                initialDirectorate = adminConfig.directorateName,
                initialAdministration = adminConfig.administrationName,
                initialDirectorGeneral = adminConfig.directorGeneralName,
                initialSecurityOfficer = adminConfig.securityOfficerName,
                onSaveAndContinue = { dir, adm, dg, sec ->
                    dataViewModel.saveAdminConfig(dir, adm, dg, sec)
                    val target = if (authState.isAuthenticated) Screen.Home.route else Screen.Login.route
                    navController.navigate(target) {
                        popUpTo(Screen.FirstTimeSetup.route) { inclusive = true }
                    }
                }
            )
        }

        // الدخول بالبصمة (كما هو)
        composable(Screen.Login.route) {
            LoginScreen(
                onAuthenticated = { authViewModel.loginWithBiometric() }
            )

            LaunchedEffect(authState.isAuthenticated) {
                if (authState.isAuthenticated) {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                }
            }
        }

        // الرئيسية
        composable(Screen.Home.route) {
            HomeScreen(
                adminConfig = adminConfig,
                schoolsCount = schools.size,
                teachersCount = teachers.size,
                eventsCount = events.size,
                onSchools = { navController.navigate(Screen.Schools.route) },
                onTeachers = { navController.navigate(Screen.Teachers.route) },
                onEvents = { navController.navigate(Screen.Events.route) },
                onReport = { navController.navigate(Screen.ReportText.route) },
                onSettings = { navController.navigate(Screen.Settings.route) }
            )
        }

        // المدارس
        composable(Screen.Schools.route) {
            SchoolsScreen(
                schools = schools,
                onSave = { dataViewModel.saveSchool(it) },
                onDelete = { dataViewModel.deleteSchool(it) },
                onBack = { navController.popBackStack() }
            )
        }

        // المعلمون
        composable(Screen.Teachers.route) {
            TeachersScreen(
                teachers = teachers,
                schools = schools,
                onSave = { dataViewModel.saveTeacher(it) },
                onDelete = { dataViewModel.deleteTeacher(it) },
                onBack = { navController.popBackStack() }
            )
        }

        // الأحداث
        composable(Screen.Events.route) {
            EventsScreen(
                events = events,
                onAddEvent = { navController.navigate(Screen.EventForm.createRoute()) },
                onEditEvent = { event -> navController.navigate(Screen.EventForm.createRoute(event.id)) },
                onDeleteEvent = { dataViewModel.deleteEvent(it) },
                onPrintEvents = { todayOnly ->
                    dataViewModel.prepareEventsReport(todayOnly)
                    navController.navigate(Screen.ReportText.route)
                },
                onBack = { navController.popBackStack() }
            )
        }

        // تسجيل / تعديل حدث
        composable(
            route = Screen.EventForm.route,
            arguments = listOf(
                navArgument("eventId") {
                    type = NavType.LongType
                    defaultValue = -1L
                }
            )
        ) { backStackEntry ->
            val eventId = backStackEntry.arguments?.getLong("eventId") ?: -1L
            EventFormScreen(
                existing = events.find { it.id == eventId },
                schools = schools,
                onSave = {
                    dataViewModel.saveEvent(it)
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }

        // صفحة إدخال النص + إرسال PDF
        composable(Screen.ReportText.route) {
            ReportTextScreen(
                draft = reportDraft,
                adminConfig = adminConfig,
                onDraftChange = { dataViewModel.setReportDraft(it) },
                onBack = { navController.popBackStack() }
            )
        }

        // الإعدادات
        composable(Screen.Settings.route) {
            SettingsScreen(
                adminConfig = adminConfig,
                onSave = { d, a, dg, s -> dataViewModel.saveAdminConfig(d, a, dg, s) },
                onLogout = {
                    authViewModel.logout()
                    navController.navigate(Screen.Login.route) {
                        popUpTo(navController.graph.id) { inclusive = true }
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }
    }
}

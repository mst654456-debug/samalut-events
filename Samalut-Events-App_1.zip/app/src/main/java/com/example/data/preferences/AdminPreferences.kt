package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AdminConfig(
    val directorateName: String = "مديرية التربية والتعليم بالمنيا",
    val administrationName: String = "إدارة سمالوط التعليمية",
    val directorGeneralName: String = "أ/ مدير عام الإدارة",
    val securityOfficerName: String = "مستر مصطفى فرغلي",
    val isSetupCompleted: Boolean = false
)

class AdminPreferences(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("admin_config_prefs", Context.MODE_PRIVATE)

    private val _adminConfig = MutableStateFlow(loadConfig())
    val adminConfig: StateFlow<AdminConfig> = _adminConfig.asStateFlow()

    private fun loadConfig(): AdminConfig {
        return AdminConfig(
            directorateName = prefs.getString(KEY_DIRECTORATE, "مديرية التربية والتعليم بالمنيا") ?: "مديرية التربية والتعليم بالمنيا",
            administrationName = prefs.getString(KEY_ADMINISTRATION, "إدارة سمالوط التعليمية") ?: "إدارة سمالوط التعليمية",
            directorGeneralName = prefs.getString(KEY_DIRECTOR_GENERAL, "أ/ مدير عام الإدارة") ?: "أ/ مدير عام الإدارة",
            securityOfficerName = prefs.getString(KEY_SECURITY_OFFICER, "مستر مصطفى فرغلي") ?: "مستر مصطفى فرغلي",
            isSetupCompleted = prefs.getBoolean(KEY_SETUP_COMPLETED, false)
        )
    }

    fun saveConfig(
        directorate: String,
        administration: String,
        directorGeneral: String,
        securityOfficer: String,
        isCompleted: Boolean = true
    ) {
        prefs.edit().apply {
            putString(KEY_DIRECTORATE, directorate.trim())
            putString(KEY_ADMINISTRATION, administration.trim())
            putString(KEY_DIRECTOR_GENERAL, directorGeneral.trim())
            putString(KEY_SECURITY_OFFICER, securityOfficer.trim())
            putBoolean(KEY_SETUP_COMPLETED, isCompleted)
            apply()
        }

        _adminConfig.value = AdminConfig(
            directorateName = directorate.trim(),
            administrationName = administration.trim(),
            directorGeneralName = directorGeneral.trim(),
            securityOfficerName = securityOfficer.trim(),
            isSetupCompleted = isCompleted
        )
    }

    fun setSetupCompleted(completed: Boolean) {
        prefs.edit().putBoolean(KEY_SETUP_COMPLETED, completed).apply()
        _adminConfig.value = _adminConfig.value.copy(isSetupCompleted = completed)
    }

    companion object {
        private const val KEY_DIRECTORATE = "key_directorate_name"
        private const val KEY_ADMINISTRATION = "key_administration_name"
        private const val KEY_DIRECTOR_GENERAL = "key_director_general_name"
        private const val KEY_SECURITY_OFFICER = "key_security_officer_name"
        private const val KEY_SETUP_COMPLETED = "key_is_setup_completed"
    }
}

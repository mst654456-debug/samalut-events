package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/** المراحل التعليمية المعتمدة */
enum class SchoolStage(val displayNameAr: String) {
    KINDERGARTEN("رياض أطفال"),
    PRIMARY("ابتدائي"),
    PREPARATORY("إعدادي"),
    GENERAL_SECONDARY("ثانوي عام"),
    TECHNICAL_SECONDARY("ثانوي فني"),
    COMMUNITY_EDUCATION("تعليم مجتمعي"),
    PRIVATE_SCHOOLS("مدارس خاصة")
}

fun stageLabel(stageName: String): String =
    SchoolStage.values().firstOrNull { it.name == stageName }?.displayNameAr ?: stageName

/** المدرسة */
@Entity(tableName = "schools")
data class School(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val stage: String = SchoolStage.PRIMARY.name,
    val code: String = "",
    val principalName: String = "",
    val phone: String = ""
)

/** المعلم */
@Entity(tableName = "teachers")
data class Teacher(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val schoolName: String,
    val jobTitle: String = "معلم",
    val phone: String = "",
    val notes: String = ""
)

/** الحدث (تسجيل الأحداث) */
@Entity(tableName = "events")
data class SchoolEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val schoolName: String,
    val description: String,
    val dateString: String,
    val timeString: String,
    val timestamp: Long
)

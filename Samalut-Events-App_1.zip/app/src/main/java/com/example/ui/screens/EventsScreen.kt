package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.SchoolEvent
import com.example.ui.components.AppTopBar
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.EmptyState

@Composable
fun EventsScreen(
    events: List<SchoolEvent>,
    onAddEvent: () -> Unit,
    onEditEvent: (SchoolEvent) -> Unit,
    onDeleteEvent: (SchoolEvent) -> Unit,
    onPrintEvents: (todayOnly: Boolean) -> Unit,
    onBack: () -> Unit
) {
    var showPrintChoice by remember { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<SchoolEvent?>(null) }

    Scaffold(
        topBar = {
            AppTopBar(
                title = "الأحداث (${events.size})",
                onBack = onBack,
                actions = {
                    IconButton(onClick = { showPrintChoice = true }) {
                        Icon(Icons.Filled.Print, contentDescription = "طباعة الأحداث")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = onAddEvent,
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("تسجيل حدث") }
            )
        }
    ) { padding ->
        if (events.isEmpty()) {
            Column(modifier = Modifier.padding(padding).fillMaxSize()) {
                EmptyState("لا توجد أحداث مسجلة بعد.\nاضغط «تسجيل حدث» للبدء.")
            }
        } else {
            LazyColumn(
                modifier = Modifier.padding(padding).fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(events, key = { it.id }) { event ->
                    EventCard(
                        event = event,
                        onClick = { onEditEvent(event) },
                        onDelete = { deleteTarget = event }
                    )
                }
            }
        }
    }

    if (showPrintChoice) {
        AlertDialog(
            onDismissRequest = { showPrintChoice = false },
            title = { Text("طباعة الأحداث", fontWeight = FontWeight.Bold) },
            text = { Text("اختر الأحداث التي تريد طباعتها في تقرير PDF، ثم يمكنك إرسالها أو طباعتها.") },
            confirmButton = {
                Row {
                    TextButton(onClick = {
                        showPrintChoice = false
                        onPrintEvents(true)
                    }) { Text("أحداث اليوم") }
                    TextButton(onClick = {
                        showPrintChoice = false
                        onPrintEvents(false)
                    }) { Text("كل الأحداث") }
                }
            },
            dismissButton = {
                TextButton(onClick = { showPrintChoice = false }) { Text("إلغاء") }
            }
        )
    }

    deleteTarget?.let { target ->
        ConfirmDialog(
            title = "حذف الحدث",
            message = "هل تريد حذف الحدث «${target.title}»؟",
            confirmText = "حذف",
            onConfirm = {
                onDeleteEvent(target)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun EventCard(event: SchoolEvent, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = event.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = onDelete) {
                    Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
                }
            }
            Text("المدرسة: ${event.schoolName}", style = MaterialTheme.typography.bodySmall)
            Text(
                "${event.dateString}  •  ${event.timeString}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = event.description,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

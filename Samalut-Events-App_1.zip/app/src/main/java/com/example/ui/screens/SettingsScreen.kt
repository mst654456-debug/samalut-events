package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.preferences.AdminConfig
import com.example.ui.components.AppTopBar

@Composable
fun SettingsScreen(
    adminConfig: AdminConfig,
    onSave: (String, String, String, String) -> Unit,
    onLogout: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var directorate by remember { mutableStateOf(adminConfig.directorateName) }
    var administration by remember { mutableStateOf(adminConfig.administrationName) }
    var directorGeneral by remember { mutableStateOf(adminConfig.directorGeneralName) }
    var securityOfficer by remember { mutableStateOf(adminConfig.securityOfficerName) }

    Scaffold(
        topBar = { AppTopBar(title = "الإعدادات", onBack = onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "البيانات الإدارية (الترويسة والتوقيعات في التقرير)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            OutlinedTextField(
                value = directorate,
                onValueChange = { directorate = it },
                label = { Text("اسم المديرية") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = administration,
                onValueChange = { administration = it },
                label = { Text("اسم الإدارة التعليمية") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = directorGeneral,
                onValueChange = { directorGeneral = it },
                label = { Text("اسم مدير عام الإدارة (يعتمد)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = securityOfficer,
                onValueChange = { securityOfficer = it },
                label = { Text("اسم مسؤول أمن الإدارة (إعداد)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (listOf(directorate, administration, directorGeneral, securityOfficer).any { it.isBlank() }) {
                        Toast.makeText(context, "جميع البيانات الإدارية مطلوبة", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    onSave(directorate.trim(), administration.trim(), directorGeneral.trim(), securityOfficer.trim())
                    Toast.makeText(context, "تم حفظ البيانات", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("حفظ البيانات", fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.height(24.dp))

            OutlinedButton(
                onClick = onLogout,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Filled.Logout, contentDescription = null)
                Text("تسجيل الخروج", fontWeight = FontWeight.Bold)
            }
        }
    }
}

package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object FirstTimeSetup : Screen("first_time_setup")
    object Login : Screen("login")
    object Home : Screen("home")
    object Schools : Screen("schools")
    object Teachers : Screen("teachers")
    object Events : Screen("events")
    object EventForm : Screen("event_form?eventId={eventId}") {
        fun createRoute(eventId: Long? = null): String =
            if (eventId == null) "event_form?eventId=-1" else "event_form?eventId=$eventId"
    }
    object ReportText : Screen("report_text")
    object Settings : Screen("settings")
}

package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.School
import com.example.data.model.SchoolEvent
import com.example.ui.components.AppTopBar
import com.example.ui.components.SchoolPickerDialog
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun EventFormScreen(
    existing: SchoolEvent?,
    schools: List<School>,
    onSave: (SchoolEvent) -> Unit,
    onBack: () -> Unit
) {
    var schoolName by remember { mutableStateOf(existing?.schoolName ?: "") }
    var title by remember { mutableStateOf(existing?.title ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var showPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { AppTopBar(title = if (existing == null) "تسجيل حدث" else "تعديل الحدث", onBack = onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) {
                Text(if (schoolName.isBlank()) "اختر المدرسة *" else "المدرسة: $schoolName")
            }

            OutlinedTextField(
                value = title,
                onValueChange = {
                    title = it
                    error = null
                },
                label = { Text("عنوان الحدث *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = description,
                onValueChange = {
                    description = it
                    error = null
                },
                label = { Text("تفاصيل الحدث *") },
                minLines = 6,
                modifier = Modifier.fillMaxWidth()
            )

            error?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    if (schoolName.isBlank()) {
                        error = "اختر المدرسة أولاً"
                        return@Button
                    }
                    if (title.isBlank()) {
                        error = "اكتب عنوان الحدث"
                        return@Button
                    }
                    if (description.isBlank()) {
                        error = "اكتب تفاصيل الحدث"
                        return@Button
                    }
                    val now = System.currentTimeMillis()
                    val event = if (existing == null) {
                        SchoolEvent(
                            title = title.trim(),
                            schoolName = schoolName,
                            description = description.trim(),
                            dateString = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date(now)),
                            timeString = SimpleDateFormat("HH:mm", Locale.US).format(Date(now)),
                            timestamp = now
                        )
                    } else {
                        existing.copy(
                            title = title.trim(),
                            schoolName = schoolName,
                            description = description.trim()
                        )
                    }
                    onSave(event)
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) {
                Text("حفظ الحدث", fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showPicker) {
        SchoolPickerDialog(
            schools = schools,
            onPick = {
                schoolName = it
                error = null
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}

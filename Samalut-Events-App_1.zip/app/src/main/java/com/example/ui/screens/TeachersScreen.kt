package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.School
import com.example.data.model.Teacher
import com.example.ui.components.AppTopBar
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.EmptyState
import com.example.ui.components.SchoolPickerDialog
import com.example.ui.components.SearchField
import com.example.ui.theme.EduBlue

@Composable
fun TeachersScreen(
    teachers: List<Teacher>,
    schools: List<School>,
    onSave: (Teacher) -> Unit,
    onDelete: (Teacher) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    var formTarget by remember { mutableStateOf<Teacher?>(null) }
    var deleteTarget by remember { mutableStateOf<Teacher?>(null) }

    val q = query.trim()
    val filtered = teachers.filter {
        it.name.contains(q, ignoreCase = true) || it.schoolName.contains(q, ignoreCase = true)
    }

    Scaffold(
        topBar = { AppTopBar(title = "المعلمون (${teachers.size})", onBack = onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    formTarget = null
                    showForm = true
                },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("إضافة معلم") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            SearchField(value = query, onValueChange = { query = it }, placeholder = "بحث بالاسم أو المدرسة")
            Spacer(modifier = Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                EmptyState(
                    if (teachers.isEmpty()) "لا يوجد معلمون مسجلون بعد.\nاضغط «إضافة معلم» للبدء."
                    else "لا توجد نتائج للبحث."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    items(filtered, key = { it.id }) { teacher ->
                        TeacherCard(
                            teacher = teacher,
                            onClick = {
                                formTarget = teacher
                                showForm = true
                            },
                            onDelete = { deleteTarget = teacher }
                        )
                    }
                }
            }
        }
    }

    if (showForm) {
        TeacherFormDialog(
            initial = formTarget,
            schools = schools,
            onSave = {
                onSave(it)
                showForm = false
            },
            onDismiss = { showForm = false }
        )
    }

    deleteTarget?.let { target ->
        ConfirmDialog(
            title = "حذف المعلم",
            message = "هل تريد حذف المعلم «${target.name}»؟",
            confirmText = "حذف",
            onConfirm = {
                onDelete(target)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun TeacherCard(teacher: Teacher, onClick: () -> Unit, onDelete: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.Person,
                contentDescription = null,
                tint = EduBlue,
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(teacher.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("${teacher.jobTitle}  •  ${teacher.schoolName}", style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun TeacherFormDialog(
    initial: Teacher?,
    schools: List<School>,
    onSave: (Teacher) -> Unit,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var schoolName by remember { mutableStateOf(initial?.schoolName ?: "") }
    var jobTitle by remember { mutableStateOf(initial?.jobTitle ?: "معلم") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var showPicker by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initial == null) "إضافة معلم" else "تعديل بيانات المعلم", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        error = null
                    },
                    label = { Text("اسم المعلم *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedButton(
                    onClick = { showPicker = true },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (schoolName.isBlank()) "اختر المدرسة *" else "المدرسة: $schoolName")
                }
                OutlinedTextField(
                    value = jobTitle,
                    onValueChange = { jobTitle = it },
                    label = { Text("الوظيفة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم التليفون") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات") },
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isBlank()) {
                    error = "اكتب اسم المعلم أولاً"
                    return@Button
                }
                if (schoolName.isBlank()) {
                    error = "اختر المدرسة التابع لها المعلم"
                    return@Button
                }
                onSave(
                    Teacher(
                        id = initial?.id ?: 0L,
                        name = name.trim(),
                        schoolName = schoolName,
                        jobTitle = jobTitle.trim().ifBlank { "معلم" },
                        phone = phone.trim(),
                        notes = notes.trim()
                    )
                )
            }) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )

    if (showPicker) {
        SchoolPickerDialog(
            schools = schools,
            onPick = {
                schoolName = it
                error = null
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}

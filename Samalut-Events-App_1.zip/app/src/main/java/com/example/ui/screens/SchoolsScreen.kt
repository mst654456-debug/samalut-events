package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.data.model.School
import com.example.data.model.SchoolStage
import com.example.data.model.stageLabel
import com.example.ui.components.AppTopBar
import com.example.ui.components.ConfirmDialog
import com.example.ui.components.EmptyState
import com.example.ui.components.SearchField
import com.example.ui.theme.EduBlue

@Composable
fun SchoolsScreen(
    schools: List<School>,
    onSave: (School) -> Unit,
    onDelete: (School) -> Unit,
    onBack: () -> Unit
) {
    var query by remember { mutableStateOf("") }
    var showForm by remember { mutableStateOf(false) }
    var formTarget by remember { mutableStateOf<School?>(null) }
    var deleteTarget by remember { mutableStateOf<School?>(null) }

    val filtered = schools.filter { it.name.contains(query.trim(), ignoreCase = true) }

    Scaffold(
        topBar = { AppTopBar(title = "المدارس (${schools.size})", onBack = onBack) },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    formTarget = null
                    showForm = true
                },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                text = { Text("إضافة مدرسة") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            SearchField(value = query, onValueChange = { query = it }, placeholder = "بحث باسم المدرسة")
            Spacer(modifier = Modifier.height(12.dp))

            if (filtered.isEmpty()) {
                EmptyState(
                    if (schools.isEmpty()) "لا توجد مدارس مسجلة بعد.\nاضغط «إضافة مدرسة» للبدء."
                    else "لا توجد نتائج للبحث."
                )
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 90.dp)
                ) {
                    items(filtered, key = { it.id }) { school ->
                        SchoolCard(
                            school = school,
                            onClick = {
                                formTarget = school
                                showForm = true
                            },
                            onDelete = { deleteTarget = school }
                        )
                    }
                }
            }
        }
    }

    if (showForm) {
        SchoolFormDialog(
            initial = formTarget,
            onSave = {
                onSave(it)
                showForm = false
            },
            onDismiss = { showForm = false }
        )
    }

    deleteTarget?.let { target ->
        ConfirmDialog(
            title = "حذف المدرسة",
            message = "هل تريد حذف مدرسة «${target.name}»؟",
            confirmText = "حذف",
            onConfirm = {
                onDelete(target)
                deleteTarget = null
            },
            onDismiss = { deleteTarget = null }
        )
    }
}

@Composable
private fun SchoolCard(school: School, onClick: () -> Unit, onDelete: () -> Unit) {
    val subtitle = if (school.principalName.isNotBlank()) {
        "المرحلة: ${stageLabel(school.stage)}  •  المدير: ${school.principalName}"
    } else {
        "المرحلة: ${stageLabel(school.stage)}"
    }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.School,
                contentDescription = null,
                tint = EduBlue,
                modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(school.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun SchoolFormDialog(initial: School?, onSave: (School) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var stage by remember { mutableStateOf(initial?.stage ?: SchoolStage.PRIMARY.name) }
    var code by remember { mutableStateOf(initial?.code ?: "") }
    var principal by remember { mutableStateOf(initial?.principalName ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (initial == null) "إضافة مدرسة" else "تعديل بيانات المدرسة",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        error = null
                    },
                    label = { Text("اسم المدرسة *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text("المرحلة", style = MaterialTheme.typography.labelLarge)
                SchoolStage.values().toList().chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        pair.forEach { st ->
                            FilterChip(
                                modifier = Modifier.weight(1f),
                                selected = stage == st.name,
                                onClick = { stage = st.name },
                                label = { Text(st.displayNameAr, maxLines = 1) }
                            )
                        }
                    }
                }
                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("كود المدرسة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = principal,
                    onValueChange = { principal = it },
                    label = { Text("اسم مدير المدرسة") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم التليفون") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                error?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isBlank()) {
                    error = "اكتب اسم المدرسة أولاً"
                    return@Button
                }
                onSave(
                    School(
                        id = initial?.id ?: 0L,
                        name = name.trim(),
                        stage = stage,
                        code = code.trim(),
                        principalName = principal.trim(),
                        phone = phone.trim()
                    )
                )
            }) {
                Text("حفظ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("إلغاء") }
        }
    )
}

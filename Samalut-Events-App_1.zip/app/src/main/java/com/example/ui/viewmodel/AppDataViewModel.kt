package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.School
import com.example.data.model.SchoolEvent
import com.example.data.model.Teacher
import com.example.data.preferences.AdminConfig
import com.example.data.preferences.AdminPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AppDataViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val adminPrefs = AdminPreferences(application)

    val adminConfig: StateFlow<AdminConfig> = adminPrefs.adminConfig

    val schools: StateFlow<List<School>> = db.schoolDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val teachers: StateFlow<List<Teacher>> = db.teacherDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val events: StateFlow<List<SchoolEvent>> = db.eventDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // نص التقرير الذي يُكتب في صفحة الإدخال ثم يتحول إلى PDF
    private val draftState = MutableStateFlow("")
    val reportDraft: StateFlow<String> = draftState.asStateFlow()

    fun setReportDraft(text: String) {
        draftState.value = text
    }

    /** يملأ نص التقرير بالأحداث (أحداث اليوم فقط أو كل الأحداث) */
    fun prepareEventsReport(todayOnly: Boolean) {
        val todayStr = SimpleDateFormat("yyyy/MM/dd", Locale.US).format(Date())
        val list = events.value
            .filter { !todayOnly || it.dateString == todayStr }
            .sortedBy { it.timestamp }
        draftState.value = buildEventsText(list, todayOnly)
    }

    private fun buildEventsText(list: List<SchoolEvent>, todayOnly: Boolean): String {
        if (list.isEmpty()) {
            return if (todayOnly) "لا توجد أحداث بالإدارة لهذا اليوم" else "لا توجد أحداث مسجلة"
        }
        val sb = StringBuilder()
        list.forEachIndexed { index, e ->
            sb.append(index + 1).append(") ").append(e.title)
            sb.append(" - مدرسة: ").append(e.schoolName).append('\n')
            sb.append("   التاريخ: ").append(e.dateString)
            sb.append("   الوقت: ").append(e.timeString).append('\n')
            sb.append("   التفاصيل: ").append(e.description).append("\n\n")
        }
        return sb.toString().trimEnd()
    }

    fun saveAdminConfig(directorate: String, administration: String, directorGeneral: String, securityOfficer: String) {
        adminPrefs.saveConfig(directorate, administration, directorGeneral, securityOfficer)
    }

    fun saveSchool(item: School) {
        viewModelScope.launch {
            if (item.id == 0L) {
                db.schoolDao().insert(item)
            } else {
                db.schoolDao().update(item)
            }
        }
    }

    fun deleteSchool(item: School) {
        viewModelScope.launch { db.schoolDao().delete(item) }
    }

    fun saveTeacher(item: Teacher) {
        viewModelScope.launch {
            if (item.id == 0L) {
                db.teacherDao().insert(item)
            } else {
                db.teacherDao().update(item)
            }
        }
    }

    fun deleteTeacher(item: Teacher) {
        viewModelScope.launch { db.teacherDao().delete(item) }
    }

    fun saveEvent(item: SchoolEvent) {
        viewModelScope.launch {
            if (item.id == 0L) {
                db.eventDao().insert(item)
            } else {
                db.eventDao().update(item)
            }
        }
    }

    fun deleteEvent(item: SchoolEvent) {
        viewModelScope.launch { db.eventDao().delete(item) }
    }
}

package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.preferences.AdminConfig
import com.example.ui.components.AppTopBar
import com.example.util.PdfReportBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ReportTextScreen(
    draft: String,
    adminConfig: AdminConfig,
    onDraftChange: (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    val canSend = draft.isNotBlank() && !busy

    fun buildPdf(onReady: (File) -> Unit) {
        busy = true
        scope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    PdfReportBuilder.build(context, draft, adminConfig)
                }
                onReady(file)
            } catch (e: Exception) {
                Toast.makeText(context, "تعذر إنشاء ملف PDF: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                busy = false
            }
        }
    }

    Scaffold(
        topBar = { AppTopBar(title = "إرسال تقرير PDF", onBack = onBack) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "اكتب نص التقرير هنا، ثم اضغط «إرسال PDF». سيخرج التقرير بترويسة الإدارة وتوقيعات المسؤولين كما في النموذج الرسمي.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            OutlinedTextField(
                value = draft,
                onValueChange = onDraftChange,
                placeholder = { Text("اكتب نص التقرير...") },
                modifier = Modifier.fillMaxWidth().weight(1f)
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = {
                        buildPdf { file -> PdfReportBuilder.share(context, file) }
                    },
                    enabled = canSend,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null)
                    Text("إرسال PDF", fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = {
                        buildPdf { file -> PdfReportBuilder.print(context, file) }
                    },
                    enabled = canSend,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f).height(52.dp)
                ) {
                    Icon(Icons.Filled.Print, contentDescription = null)
                    Text("طباعة", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

package com.example.util

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.data.preferences.AdminConfig
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * ينشئ تقرير PDF على صفحات A4 بنفس تخطيط الورقة الرسمية:
 * - ترويسة في أعلى اليمين (المديرية / الإدارة / مكتب الأمن) وخط فاصل تحتها
 * - متن التقرير من النص المكتوب، ويكمل تلقائياً على صفحات إضافية عند الحاجة
 * - توقيعات في أسفل آخر صفحة: يمين (إعداد / مسئول الأمن) ويسار (يعتمد / مدير عام الإدارة)
 */
object PdfReportBuilder {

    private const val PAGE_WIDTH = 595
    private const val PAGE_HEIGHT = 842
    private const val LEFT = 40f
    private const val RIGHT = 555f
    private const val BODY_TOP = 150f
    private const val BODY_BOTTOM = 700f
    private const val FOOTER_LINE_Y = 730f

    fun build(context: Context, text: String, config: AdminConfig): File {
        val dir = File(context.cacheDir, "reports").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(dir, "Samalut_Report_$stamp.pdf")

        val font: Typeface = ResourcesCompat.getFont(context, R.font.cairo) ?: Typeface.DEFAULT
        val dateText = SimpleDateFormat("dd / MM / yyyy", Locale.US).format(Date())

        val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = Color.rgb(30, 35, 45)
            textSize = 14f
            typeface = font
        }
        val layout: Layout? = if (text.isBlank()) null else StaticLayout.Builder
            .obtain(text, 0, text.length, bodyPaint, (RIGHT - LEFT).toInt())
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(TextDirectionHeuristics.RTL)
            .setLineSpacing(0f, 1.45f)
            .setIncludePad(false)
            .build()

        val lineCount = layout?.lineCount ?: 0
        val available = BODY_BOTTOM - BODY_TOP
        val doc = PdfDocument()
        try {
            var startLine = 0
            var pageNo = 1
            var isLast = false
            do {
                val page = doc.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNo).create())
                val canvas = page.canvas
                drawHeader(canvas, font, config, dateText)

                if (layout != null && startLine < lineCount) {
                    val lineTop = layout.getLineTop(startLine).toFloat()
                    var endLine = startLine + 1
                    while (endLine < lineCount && layout.getLineBottom(endLine) - lineTop <= available) {
                        endLine++
                    }
                    // نقص الرسم عند نهاية آخر سطر يدخل الصفحة حتى لا يظهر نصف سطر
                    val clipBottom = BODY_TOP + (layout.getLineBottom(endLine - 1) - lineTop)
                    canvas.save()
                    canvas.clipRect(LEFT, BODY_TOP, RIGHT, clipBottom)
                    canvas.translate(LEFT, BODY_TOP - lineTop)
                    layout.draw(canvas)
                    canvas.restore()
                    startLine = endLine
                }

                isLast = startLine >= lineCount
                if (isLast) drawSignatures(canvas, font, config)
                doc.finishPage(page)
                pageNo++
            } while (!isLast)

            FileOutputStream(file).use { doc.writeTo(it) }
        } finally {
            doc.close()
        }
        return file
    }

    private fun drawHeader(canvas: Canvas, font: Typeface, config: AdminConfig, dateText: String) {
        val headerPaint = textPaint(font, 14f, Color.rgb(20, 30, 50), Paint.Align.RIGHT, bold = true)
        canvas.drawText(config.directorateName, RIGHT, 55f, headerPaint)
        canvas.drawText(config.administrationName, RIGHT, 75f, headerPaint)
        canvas.drawText("مكتب الأمن", RIGHT, 95f, headerPaint)

        val datePaint = textPaint(font, 11f, Color.rgb(90, 100, 115), Paint.Align.LEFT)
        canvas.drawText("التاريخ: $dateText", LEFT, 55f, datePaint)

        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = Color.rgb(21, 101, 192)
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        canvas.drawLine(LEFT, 115f, RIGHT, 115f, linePaint)
    }

    private fun drawSignatures(canvas: Canvas, font: Typeface, config: AdminConfig) {
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = Color.rgb(180, 190, 200)
            strokeWidth = 1.5f
            style = Paint.Style.STROKE
        }
        canvas.drawLine(LEFT, FOOTER_LINE_Y, RIGHT, FOOTER_LINE_Y, footerPaint)

        val titleRight = textPaint(font, 13f, Color.rgb(20, 30, 50), Paint.Align.RIGHT, bold = true)
        val nameRight = textPaint(font, 14f, Color.rgb(21, 101, 192), Paint.Align.RIGHT, bold = true)
        val titleLeft = textPaint(font, 13f, Color.rgb(20, 30, 50), Paint.Align.LEFT, bold = true)
        val nameLeft = textPaint(font, 14f, Color.rgb(21, 101, 192), Paint.Align.LEFT, bold = true)

        canvas.drawText("إعداد / مسئول الأمن", RIGHT, FOOTER_LINE_Y + 28f, titleRight)
        canvas.drawText(config.securityOfficerName, RIGHT, FOOTER_LINE_Y + 55f, nameRight)

        canvas.drawText("يعتمد / مدير عام الإدارة", LEFT, FOOTER_LINE_Y + 28f, titleLeft)
        canvas.drawText(config.directorGeneralName, LEFT, FOOTER_LINE_Y + 55f, nameLeft)
    }

    private fun textPaint(font: Typeface, size: Float, color: Int, align: Paint.Align, bold: Boolean = false): Paint {
        return Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            textSize = size
            typeface = font
            isFakeBoldText = bold
            textAlign = align
        }
    }

    /** مشاركة الملف عبر تطبيقات الهاتف (واتساب، البريد، Drive...) */
    fun share(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            clipData = ClipData.newRawUri("report", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "إرسال التقرير PDF"))
    }

    /** طباعة الملف عبر خدمة الطباعة في الهاتف */
    fun print(context: Context, file: File) {
        val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
        val adapter = object : PrintDocumentAdapter() {
            override fun onLayout(
                oldAttributes: PrintAttributes?,
                newAttributes: PrintAttributes?,
                cancellationSignal: CancellationSignal?,
                callback: PrintDocumentAdapter.LayoutResultCallback?,
                extras: Bundle?
            ) {
                if (cancellationSignal?.isCanceled == true) {
                    callback?.onLayoutCancelled()
                    return
                }
                val info = PrintDocumentInfo.Builder(file.name)
                    .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                    .setPageCount(PrintDocumentInfo.PAGE_COUNT_UNKNOWN)
                    .build()
                callback?.onLayoutFinished(info, true)
            }

            override fun onWrite(
                pages: Array<out PageRange>?,
                destination: ParcelFileDescriptor?,
                cancellationSignal: CancellationSignal?,
                callback: PrintDocumentAdapter.WriteResultCallback?
            ) {
                try {
                    val target = destination?.fileDescriptor
                        ?: throw IllegalStateException("لا يوجد ملف وجهة للطباعة")
                    FileInputStream(file).use { input ->
                        FileOutputStream(target).use { output -> input.copyTo(output) }
                    }
                    callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
                } catch (e: Exception) {
                    callback?.onWriteFailed(e.message)
                }
            }
        }
        printManager.print("تقرير أحداث سمالوط", adapter, PrintAttributes.Builder().build())
    }
}
